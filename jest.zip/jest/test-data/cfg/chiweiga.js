// This file is part of JEST.
// 
// JEST is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your
// option) any later version.
// 
// JEST is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the LICENSE for more details.
// 
// A copy of the GNU General Public License should have been included
// along with JEST in a file named LICENSE. If not, see
// <http://www.gnu.org/licenses/>.


do
for (var FÄM = (! function T (Å)
                  {
                  },
                /Z/); null << function B (o)
                               {
                               }.iy;)
do
{
} while (delete ""); while (13.520847250638834);
for (; ""; new [i](e).ÚOFa)
function VFÚn(hCXH,ywñò,mfNc,zm¾k)
{
  if (2)
  ÕÆ:
  return 1;
  else throw 0.8675147712702772;
  break ÎIÂ;
}
