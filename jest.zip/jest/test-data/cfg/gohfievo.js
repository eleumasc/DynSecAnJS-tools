// This file is part of JEST.
// 
// JEST is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your
// option) any later version.
// 
// JEST is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the LICENSE for more details.
// 
// A copy of the GNU General Public License should have been included
// along with JEST in a file named LICENSE. If not, see
// <http://www.gnu.org/licenses/>.


while (false ^ (true ? false : $S))
if (function ÜZ (k1,EC)
    {
    }.j4Ú)
e5N:
do
l:
break; while ("1");
for (; this[function CnV (a2h,éàd,UAµ)
            {
            }]; false)
for (; [];)
while (true)
;
if (new this(1)(2,["".Y])) ;
