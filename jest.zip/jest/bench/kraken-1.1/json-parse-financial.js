
for (var i = 0; i < 1000; i++) {
  var x = JSON.parse(data);
}
