
for (var i = 0; i < 20; i++) {
  var x = JSON.stringify(tinderbox_data);
}