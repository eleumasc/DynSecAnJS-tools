function f()
{
}

for (var i = 0; i < 4000000; ++i)
    f();
