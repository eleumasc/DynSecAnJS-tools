for (var i = 0; i < 10000000; ++i)
    ;
