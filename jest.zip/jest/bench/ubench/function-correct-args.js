function f(x0, x1, x2, x3, x4, x5, x6, x7, x8, x9)
{
}

for (var i = 0; i < 3000000; ++i)
    f(0, 1, 2, 3, 4, 5, 6, 7, 8, 9);
