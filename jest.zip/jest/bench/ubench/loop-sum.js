var count = 6000000;
var sum = 0;
for (var i = 0; i < count; i++) {
    sum = i + count;
}
