if (a > b)
else c = d
