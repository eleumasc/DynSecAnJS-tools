while (i < 10) {
  ++i;
}


