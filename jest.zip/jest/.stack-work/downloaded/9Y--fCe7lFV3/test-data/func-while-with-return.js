function f () {
 do with (0) return P
 while (null);
}
