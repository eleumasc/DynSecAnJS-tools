for (var i in 3 in {}) {
}
