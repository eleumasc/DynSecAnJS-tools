while (x) {
    break;
}
