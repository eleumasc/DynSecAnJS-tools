new jQuery + 10
