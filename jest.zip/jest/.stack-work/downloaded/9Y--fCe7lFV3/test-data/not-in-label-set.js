l1 : {
    l2: for (x in o) 
    continue l1;
}
