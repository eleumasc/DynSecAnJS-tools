if (!(foo == bar) )
  x = 10;
else if (foo != bar) {
  x = 20;
} else {
  x = 30;
}
