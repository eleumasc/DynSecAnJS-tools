switch (a) {
  case 1: x = 2
     break l1;
  default: x = 3
}
