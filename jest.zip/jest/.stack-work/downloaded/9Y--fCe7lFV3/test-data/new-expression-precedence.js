
new obj[foo](bar )
new foo.bar(cux)[qux]
