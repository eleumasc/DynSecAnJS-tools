if (foo)
  bar();
if (bar)
  cux();
else
  baz();
  
