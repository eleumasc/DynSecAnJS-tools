"hel\
lo";
'wor\
ld';
