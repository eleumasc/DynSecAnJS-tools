l1: while (x) {
    (function () {
    break l1;
    })();
}
