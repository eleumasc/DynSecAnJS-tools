function foo () { 
  var x = g();
  if (x == 10) {
     x = 20;
  }
}
