(function(foo) {
  return foo;
})(10);
