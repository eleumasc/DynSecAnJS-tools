var x = 10;
var y = 20;
