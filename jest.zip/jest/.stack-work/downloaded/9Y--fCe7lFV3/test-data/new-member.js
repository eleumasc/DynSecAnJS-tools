new jQuery( selector, context, rootjQuery )
