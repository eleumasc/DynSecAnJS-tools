while ( node ) {
    if ( useCache ) {
    }
    if ( node === elem ) {
        break;
    }
}
