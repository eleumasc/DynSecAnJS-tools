a = b
++c