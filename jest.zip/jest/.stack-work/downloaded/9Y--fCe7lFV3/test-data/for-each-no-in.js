for (var i = 1 + (2 in {}) in {} in {});

