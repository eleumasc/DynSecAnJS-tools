l1: {
    while (1) continue l1;
}
