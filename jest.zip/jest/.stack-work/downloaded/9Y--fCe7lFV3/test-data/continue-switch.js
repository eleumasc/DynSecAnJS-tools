switch (a) {
  case 1: x = 2
          continue;
  default: x = 3
}
