switch (a) {
  case 1: x = 2
     break
  default: x = 3
}
