l1: x = 1;
while (x) continue l1;
