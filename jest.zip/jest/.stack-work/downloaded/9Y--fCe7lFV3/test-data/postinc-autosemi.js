i
++
j
