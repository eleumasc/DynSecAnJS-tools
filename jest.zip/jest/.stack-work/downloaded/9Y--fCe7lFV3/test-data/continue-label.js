l1: while (x) 
    continue l1;
