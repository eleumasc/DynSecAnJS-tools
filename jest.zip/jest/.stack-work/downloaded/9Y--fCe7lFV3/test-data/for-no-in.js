for (var i in array; i < 10; i++);
