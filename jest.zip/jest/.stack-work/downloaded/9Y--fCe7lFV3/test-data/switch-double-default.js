switch (foo) {
    case 10: console.log('10!');
    case 20: console.log('20!');
    default: console.log('something else!');
    case 30: console.log('30!');
    default: console.log('something else!');
};
