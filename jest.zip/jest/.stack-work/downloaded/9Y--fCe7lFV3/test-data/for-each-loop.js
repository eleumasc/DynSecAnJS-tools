for (var i in foos) {
    foo();
}

