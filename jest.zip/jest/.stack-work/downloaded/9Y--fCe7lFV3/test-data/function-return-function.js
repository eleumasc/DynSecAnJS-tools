(function() {
  return function() { };
})
