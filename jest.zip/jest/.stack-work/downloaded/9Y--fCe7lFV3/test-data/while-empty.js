while (i++ < 10);
