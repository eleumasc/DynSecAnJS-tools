jespresso
=========

A library for extracting and consolidating JavaScript in HTML pages.
