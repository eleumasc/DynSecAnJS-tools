module Main where

main = return ()
